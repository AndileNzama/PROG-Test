/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication25;

/**
 *
 * @author andilenzama
 */

public abstract class EstateAgent {
    private String agentName;
    private double propertyPrice;
    public EstateAgent(String agentName, double propertyPrice) {
        this.agentName = agentName;
        this.propertyPrice = propertyPrice;
    }
    public String getAgentName() {
        return agentName;
    }
    public double getPropertyPrice() {
        return propertyPrice;
    }
    public double getAgentCommission() {
        return 0.20 * propertyPrice; // Commission is 20% of property price
    }
    public static void main(String[] args) {
        NewInterface.EstateAgentSales agent = new NewInterface.EstateAgentSales("John Doe", 200000.0);
        System.out.println("Estate Agent Name: " + agent.getAgentName());
        System.out.println("Property Price: $" + agent.getPropertyPrice());
        System.out.println("Agent Commission: $" + agent.getAgentCommission());
    }
}
