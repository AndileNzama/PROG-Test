/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package javaapplication25;

/**
 *
 * @author andilenzama
 */
public interface NewInterface {
    public interface iEstateAgent {
    String getAgentName();
    double getPropertyPrice();
    double getAgentCommission();
}
public class EstateAgentSales extends EstateAgent implements iEstateAgent {
    public EstateAgentSales(String agentName, double propertyPrice) {
        super(agentName, propertyPrice);
    }
    public static void main(String[] args) {
        EstateAgentSales agent = new EstateAgentSales("John Doe", 200000.0);
        System.out.println("Estate Agent Name: " + agent.getAgentName());
        System.out.println("Property Price: $" + agent.getPropertyPrice());
        System.out.println("Agent Commission: $" + agent.getAgentCommission());
    }
}

    
}
