/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

public class CameraTechnologyReport {

    public static void main(String[] args) {

        // Create a two-dimensional array to store the camera cost comparisons.
        String[][] cameraCostComparisons = {
            {"MIRRORLESS", "DSLR", "CANON", "10500", "8500"},
            {"MIRRORLESS", "DSLR", "SONY", "9500", "7200"},
            {"MIRRORLESS", "DSLR", "NIKON", "12000", "8000"}
        };

        // Calculate the price difference between DSLR and Mirrorless cameras for each manufacturer.
        int[] priceDifferences = new int[cameraCostComparisons.length];
        for (int i = 0; i < cameraCostComparisons.length; i++) {
            int dslrCost = Integer.parseInt(cameraCostComparisons[i][3]);
            int mirrorlessCost = Integer.parseInt(cameraCostComparisons[i][4]);
            priceDifferences[i] = dslrCost - mirrorlessCost;
        }

        // Find the camera manufacturer with the greatest cost difference.
        int greatestCostDifferenceIndex = 0;
        for (int i = 1; i < priceDifferences.length; i++) {
            if (priceDifferences[i] > priceDifferences[greatestCostDifferenceIndex]) {
                greatestCostDifferenceIndex = i;
            }
        }

        // Display the camera technology report.
        System.out.println("CAMERA TECHNOLOGY REPORT");
        System.out.println("=========================");
        System.out.println("Camera Manufacturer | DSLR Cost | Mirrorless Cost | Price Difference | Stars");
        System.out.println("-----------------------|-----------|----------------|----------------|-------");
        for (int i = 0; i < cameraCostComparisons.length; i++) {
            System.out.println(cameraCostComparisons[i][2] + " | " + cameraCostComparisons[i][3] + " | " + cameraCostComparisons[i][4] + " | " + priceDifferences[i] + " | " + (priceDifferences[i] >= 2500 ? "***" : ""));
        }
        System.out.println("=========================");

        // Display the camera manufacturer with the greatest cost difference.
        System.out.println("Camera manufacturer with the greatest cost difference: " + cameraCostComparisons[greatestCostDifferenceIndex][2]);
    }
}
