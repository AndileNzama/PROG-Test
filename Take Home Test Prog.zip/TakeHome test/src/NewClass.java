/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author andilenzama
 */
public class NewClass {
    // Define the iEstateAgent interface
public interface iEstateAgent {
    String getAgentName();
    double getPropertyPrice();
    double getAgentCommission();
}

// Define the abstract EstateAgent class
abstract class EstateAgent implements iEstateAgent {
    private String agentName;
    private double propertyPrice;

    public EstateAgent(String agentName, double propertyPrice) {
        this.agentName = agentName;
        this.propertyPrice = propertyPrice;
    }

    public String getAgentName() {
        return agentName;
    }

    public double getPropertyPrice() {
        return propertyPrice;
    }

    public double getAgentCommission() {
        return 0.20 * propertyPrice; // Calculate commission as 20% of the property price
    }
}

// Define the EstateAgentSales subclass
class EstateAgentSales extends EstateAgent {
    public EstateAgentSales(String agentName, double propertyPrice) {
        super(agentName, propertyPrice);
    }

    public void printPropertyReport() {
        System.out.println("Estate Agent Name: " + getAgentName());
        System.out.println("Property Sale Price: $" + getPropertyPrice());
        System.out.println("Estate Agent Commission: $" + getAgentCommission());
    }
}

// Define the RunApplication class
public class RunApplication {
    public static void main(String[] args) {
        // Create an instance of EstateAgentSales
        EstateAgentSales agent = new EstateAgentSales("John Doe", 1000000.0);

        // Print the property report
        agent.printPropertyReport();
    }
}

    
}
